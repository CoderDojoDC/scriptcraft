for (var x=1;x<100;x++) { 
    d=new Drone().fwd(x); 
    d.box( x,1,1,1 );
}