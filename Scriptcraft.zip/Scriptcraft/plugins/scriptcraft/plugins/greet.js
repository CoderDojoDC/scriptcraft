exports.greet = function( player ) {
   player.sendMessage('Hello ' + player.name );
};
